# Importing Libraries
import os


# rds settings
rds_host = os.environ['rds_instance_endpoint']
name = os.environ['db_username']
password = os.environ['db_password']
db_name = os.environ['db_name']

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }